using UnityEngine;
using UnityEngine.UI;
using System.Collections;

[RequireComponent(typeof(Rigidbody))]
public class CheckpointSystem : MonoBehaviour
{
    [Header("Respawn Settings")]
    public Vector3 currentRespawnPos;

    [Header("Fade Settings")]
    public Image fadeScreen;
    public float fadeSpeed = 3f;

    private Rigidbody rb;
    private MovementTech movementScript;
    private bool isRespawning = false;

    void Start()
    {
        rb = GetComponent<Rigidbody>();
        movementScript = GetComponent<MovementTech>();
        currentRespawnPos = transform.position;
    }

    void OnTriggerEnter(Collider other)
    {
        if (other.CompareTag("Checkpoint"))
        {
            currentRespawnPos = other.transform.position;
            other.enabled = false;
        }
        else if (other.CompareTag("Killzone") && !isRespawning)
        {
            DeathSequenceManager deathManager = FindObjectOfType<DeathSequenceManager>();
            if (deathManager != null)
            {
                deathManager.TriggerDeath();
            }
            else
            {
                StartCoroutine(RespawnRoutine());
            }
        }
    }

    public void Respawn()
    {
        if (!isRespawning) StartCoroutine(RespawnRoutine());
    }

    IEnumerator RespawnRoutine()
    {
        isRespawning = true;

        int currentDeaths = PlayerPrefs.GetInt("SessionDeaths", 0);
        PlayerPrefs.SetInt("SessionDeaths", currentDeaths + 1);
        PlayerPrefs.Save();

        if (SideQuestManager.Instance != null) SideQuestManager.Instance.FailQuest();
        TutorialTimeTrial tutorial = FindObjectOfType<TutorialTimeTrial>();
        if (tutorial != null) tutorial.ResetTutorialRoom();
        float alpha = 0f;
        while (alpha < 1f)
        {
            alpha += Time.deltaTime * fadeSpeed;
            if (fadeScreen != null) fadeScreen.color = new Color(0, 0, 0, alpha);
            yield return null;
        }

        if (rb != null)
        {
            rb.position = currentRespawnPos;
            rb.linearVelocity = Vector3.zero;
            rb.angularVelocity = Vector3.zero;
        }
        else
        {
            transform.position = currentRespawnPos;
        }

        if (movementScript != null) movementScript.ResetDash();

        yield return new WaitForSeconds(0.2f);

        while (alpha > 0f)
        {
            alpha -= Time.deltaTime * fadeSpeed;
            if (fadeScreen != null) fadeScreen.color = new Color(0, 0, 0, alpha);
            yield return null;
        }

        isRespawning = false;
    }
}